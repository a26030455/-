# Factory-lottery-system
工廠抽籤系統-made by 子翔
